const mongoose = require("mongoose");

const phraseSchema = new mongoose.Schema({
    phrase: String,
    translations: Object,
});

// Create a model
const Phrase = mongoose.model('Phrase', phraseSchema);

module.exports(Phrase);