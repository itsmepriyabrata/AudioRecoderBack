const mongoose = require("mongoose");

const userSchema = new mongoose.Schema(
    {
        googleID: String,
        displayName:String,
        email:String,
        password:String,
        image:String
    },{timestamps:true})

const userdb = new mongoose.model("SLogin",userSchema);

module.exports = {userdb};