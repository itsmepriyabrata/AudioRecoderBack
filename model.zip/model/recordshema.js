const mongoose = require("mongoose");


const recordSchema = new mongoose.Schema({
    language: String,
    transcript: String,
    phrase: String,
    mediatype: String,
    User_ID: String,
    filePath: String,
    Duration:Number,
    Vector:Number,
    Downloads: Number
});
const Recording = mongoose.model('Recording', recordSchema);

module.exports = {Recording};